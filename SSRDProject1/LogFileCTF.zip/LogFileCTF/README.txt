**Find the Flag in a Log File (Forensics CTF) - README**

### **Challenge Overview**
In this Capture the Flag (CTF) challenge, your goal is to locate a hidden flag within a log file. The log file contains multiple entries, including system logs, fake flags, and misleading information. You must use your forensics skills to extract the correct flag.

### **Difficulty Level**
 Beginner

### **Objective**
Find the correct flag hidden within `server.log` and decode it if necessary.

---

### **Solving the Challenge**
#### **1. Navigate to the Log File Directory**
```bash
cd ~/Path/
```

#### **2. Search for the Flag**
Use `grep` to find potential flag entries:
```bash
grep "flag" server.log
```

#### **3. Decode the Hidden Flag**
If you find a base64-encoded flag, decode it with:
```bash
echo "<base64_string>" | base64 -d
```
Example:
```bash
echo "ZmxhZ3toaWRkZW5faW5fbG9nc30K" | base64 -d
```
Expected Output:
```plaintext
flag{hidden_in_logs}
```
---

### **Winning Condition**
You successfully complete the challenge when you find and decode the correct flag.

